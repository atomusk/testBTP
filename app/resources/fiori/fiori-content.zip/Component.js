sap.ui.define(['sap/fe/core/AppComponent'], function (AppComponent) {
    'use strict';

    return AppComponent.extend("app_abn-fiori.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
