sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("ns.app_abn.controller.DetailObjectNotFound", {});
});